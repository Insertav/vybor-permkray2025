#ifndef _CP_BLINDSIG_H_INCLUDED
#define _CP_BLINDSIG_H_INCLUDED

#ifndef UNIX
#include <windows.h>
#include <wincrypt.h>
#else // UNIX
#include "CSP_WinCrypt.h"
#include <dlfcn.h>
#endif // UNIX

#include "WinCryptEx.h"

#ifdef __cplusplus
extern "C" {
#endif

#define szOID_CryptoPro_private_keys_extension_blind_signature_public_key "1.2.643.2.2.37.3.18"

typedef ULONG_PTR HBS_CONTEXT;
typedef ULONG_PTR HVOTE_CONTEXT;
typedef ULONG_PTR HBULLETIN_SUM_CONTEXT;

void FreeDataBlob(CRYPT_DATA_BLOB* pBuffer);

// ������ �������
#define BLIND_SIGNATURE_TZ22	1
#define BLIND_SIGNATURE_ABE	2
#define BLIND_SIGNATURE_BRANDS	3

#define CPBLINDSIG_OID_TC26_256B	1

#define HBS_CONTEXT_EMPTY	1
#define HBS_CONTEXT_IN_WORK	2
#define HBS_CONTEXT_DONE	3
#define HBS_CONTEXT_BROKEN	4

// ��������� ��� ��������� ���������
#define CPBLINDSIG_BULLETIN_VERSION_0	    0

#define CPBLINDSIG_BULLETIN_PLAIN	    0
#define CPBLINDSIG_BULLETIN_ENCRYPTED	    1
#define CPBLINDSIG_BULLETIN_SUM		    2
#define CPBLINDSIG_BULLETIN_DECRYPTED_PART  3
#define CPBLINDSIG_BULLETIN_RESULT	    4

BOOL CreateSignerBlindSignatureContext(HBS_CONTEXT *phSignerContext, LPCSTR szProvName, DWORD dwProvType, LPCSTR szContName, const BYTE *pbPin, DWORD dwBlindSignatureType, LPCSTR szOid, DWORD dwFlags);
BOOL OpenSignerBlindSignatureContext(HBS_CONTEXT *phSignerContext, LPCSTR szProvName, DWORD dwProvType, LPCSTR szContName, const BYTE *pbPin, DWORD dwFlags);
BOOL GetSignerBlindSignaturePublicKey(const HBS_CONTEXT hSignerContext, CRYPT_DATA_BLOB* pcdbPublicKey);
BOOL CreateUserBlindSignatureContext(HBS_CONTEXT *phUserContext, const CRYPT_DATA_BLOB* pcdbPublicKey, const CRYPT_DATA_BLOB* pcdbMessage);
BOOL UpdateBlindSignatureContext(HBS_CONTEXT hContext, const CRYPT_DATA_BLOB* pcdbInputData, CRYPT_DATA_BLOB* pcdbOutputData);
BOOL GetBlindSignatureContextState(const HBS_CONTEXT hContext, DWORD *pdwContextState);
BOOL VerifyBlindSignature(const CRYPT_DATA_BLOB* pcdbPublicKey, const CRYPT_DATA_BLOB* pcdbMessage, const CRYPT_DATA_BLOB* pcdbSignatureValue);
BOOL ResetSignerBlindSignatureContext(HBS_CONTEXT hSignerContext);
BOOL DuplicateSignerBlindSignatureContext(const HBS_CONTEXT hSignerContext, HBS_CONTEXT* phDuplicateSignerContext, DWORD dwFlags);
BOOL ReleaseBlindSignatureContext(HBS_CONTEXT *pContext);

// ���������� ����������

// ���������� � ����� ����������
#define ENCRYPTION_PUBLIC_CALCMETHOD_1	1

BOOL CalcEncryptionPublic(const char* pcCurveOid, DWORD dwCalcMethod, DWORD dwParts, const CRYPT_DATA_BLOB* pcdbPublicKeys, CRYPT_DATA_BLOB* pcdbCoeffs, CRYPT_DATA_BLOB* pcdbMainPublic);

// ��������� "��������� �������"
typedef struct _VOTING_PARAMS_
{
    DWORD dwFields;
    DWORD dwMinFieldsChecked;
    DWORD dwMaxFieldsChecked;
    const char *pcCurveOid;
    CRYPT_DATA_BLOB cdbPublicKey;
} VOTING_PARAMS;

BOOL CreateVotingContext(HVOTE_CONTEXT *phVotingContext, const VOTING_PARAMS *pVotingParams);
BOOL DestroyVotingContext(HVOTE_CONTEXT *phVotingContext);

// ��������� ��������� ���������
typedef struct _BULLETIN_HEADER_ {
    BYTE bBulletinType;
    BYTE bVersion;
    BYTE bCurveID;
    BYTE bReserved;
    DWORD dwFields;
} BULLETIN_HEADER;

BOOL CreateUserBulletin(const HVOTE_CONTEXT hVotingContext, CRYPT_DATA_BLOB *pcdbUserBulletin);
BOOL ChooseUserBulletinField(const HVOTE_CONTEXT hVotingContext, CRYPT_DATA_BLOB *pcdbUserBulletin, DWORD dwField);
BOOL EncryptUserBulletin(const HVOTE_CONTEXT hVotingContext, const CRYPT_DATA_BLOB *pcdbContext, CRYPT_DATA_BLOB *pcdbUserBulletin);
BOOL VerifyEncryptedUserBulletin(const HVOTE_CONTEXT hVotingContext, const CRYPT_DATA_BLOB *pcdbContext, const CRYPT_DATA_BLOB *pcdbUserBulletin);

// ������� ������ �����������
BOOL CreateBulletinSumContext(const HVOTE_CONTEXT hVotingContext, HBULLETIN_SUM_CONTEXT* phBulletinSumContext);
BOOL AddEncryptedBulletinToSumContext(const HVOTE_CONTEXT hVotingContext, HBULLETIN_SUM_CONTEXT hBulletinSumContext, const CRYPT_DATA_BLOB *pcdbUserBulletin, BOOL bVerifyBulletin, const CRYPT_DATA_BLOB *pcdbContext);
BOOL GetSumFromSumContext(const HVOTE_CONTEXT hVotingContext, const HBULLETIN_SUM_CONTEXT hBulletinSumContext, CRYPT_DATA_BLOB *pcdbSum);
BOOL AddSumToSumContext(const HVOTE_CONTEXT hVotingContext, HBULLETIN_SUM_CONTEXT hBulletinSumContext, const CRYPT_DATA_BLOB *pcdbSum);
BOOL DestroyBulletinSumContext(HBULLETIN_SUM_CONTEXT* phBulletinSumContext);

// ������������� � �������� ����������
BOOL GetDecryptionPart(const CRYPT_DATA_BLOB *pcdbSum, LPCSTR szProvName, DWORD dwProvType, LPCSTR szContName, const BYTE *pbPin, const CRYPT_DATA_BLOB *pcdbContext, CRYPT_DATA_BLOB *pcdbDecryptedSum);
BOOL VerifyDecryptedPart(const CRYPT_DATA_BLOB *pcdbSum, const CRYPT_DATA_BLOB *pcdbPublicKey, const CRYPT_DATA_BLOB *pcdbContext, const CRYPT_DATA_BLOB *pcdbDecryptedSum);
BOOL FinalizeDecryption(const CRYPT_DATA_BLOB *pcdbSum, DWORD dwParts, const CRYPT_DATA_BLOB *pcdbDecryptedSums, const CRYPT_DATA_BLOB *pcdbCoeffs, CRYPT_DATA_BLOB *pcdbFinalResult);
#ifdef __cplusplus
}
#endif

#endif //_CP_BLINDSIG_H_INCLUDED
